# @sangeev/estate-ui

Versioned visual contract for Sangeev's public web estate.

Casebook candidate: `2.0.0-alpha.6`. Existing four-site fleet remains pinned to `2.0.0-alpha.4`; this is not a coordinated rollout.

The package owns the selected Evidence Window × Drenched Atlas × Field Ledger shared surface: tokens, local fonts, estate header/theme behavior, named shell variants, title roles, registration rule, safety boundary, evidence frame, focus and reduced-motion behavior.

Dark mode uses **Deep Atlas**: `#061e1d` canvas, `#041615` chrome, `#0b2b29` panels and `#123a37` raised surfaces. Primary and secondary text are `#d4e3df` and `#9bb8b1`. Coral remains exactly `#ff7a66` in both themes, with dark ink labels on coral fills. Light mode retains its existing palette.

Use semantic roles for theme-aware application surfaces. The original `--estate-atlas`, `--estate-deep`, `--estate-mist` and other base colours are deliberately invariant; they are not a dark-mode mapping. New `--estate-night*` primitives back dark semantic roles, while `--estate-rule` distinguishes decorative dividers from accessible `--border`/`--input` edges. `--estate-link` is readable text, never a large surface fill. Paired boundary/chrome roles prevent pale islands and preserve contrast. Private/native adapters must translate these same roles and be verified separately; installing this React/CSS package cannot update a native app or remote desktop theme.

It deliberately does not contain application-specific workflows or page bodies.

Every consumer must call `initialiseEstateTheme()` before its first React render, then use `useEstateTheme()` for the shared toggle. Casebook uses `PublicEstateHeader current="casebook"`, the existing `wide-app` shell and app title role at `/` only. There is no invented Casebook public URL and no sibling link is marked current. No shared visual styles changed in this candidate.

The repository remains private and the package is not npm-published (`private: true`). First-party code is licensed under MIT (see `LICENSE`); the archive is intentionally distributable in public Casebook. Bundled fonts remain under their upstream OFL terms in `LICENSES/`. Do not run `pack:estate`, `release:stage` or `release:check` for this candidate: those legacy fleet workflows copy/install/build across sibling repositories. Use `npm pack --ignore-scripts --pack-destination <scratch-directory>` twice and compare SHA-256 instead.

The manifest's top-level artifact still describes the four existing apps. Casebook has an explicit per-site `artifact` override. Source, integration and browser checks use per-site expectations; an aggregate pass does not mean every app runs the candidate. Default checks include Casebook and will fail until its integration is complete.

After the Casebook owner vendors and installs the exact candidate and copies the two canonical `LICENSES/OFL-*.txt` files verbatim into `public/licenses/`:

```sh
ESTATE_AUDIT_SITE=casebook node --test tests/integration.test.mjs
ESTATE_AUDIT_SITE=casebook npm run audit:source
ESTATE_AUDIT_SITE=casebook npm run audit:browser -- /absolute/scratch/evidence
```

The browser command normally installs/builds **only the selected app**. To inspect an already built app without installs/builds, add `ESTATE_SKIP_PREPARE=1`. It checks `/` at 390×844 and 1536×1024, both themes. No `/app/` route is required. `ESTATE_AUDIT_SITE=fleet npm test` and `ESTATE_AUDIT_SITE=fleet npm run audit:source` retain read-only verification of the old four app pins; the browser selector accepts individual sites/routes, not `fleet`.
